'use client';

import { signIn, signOut, useSession } from 'next-auth/react';

export function AuthButtons() {
  const { data: session, status } = useSession();

  if (status === 'loading') return <p>Loading...</p>;

  if (session) {
    return (
      <div className="flex items-center gap-4">
        <p>👋 Hello, {session.user?.name}</p>
        <button
          onClick={() => signOut()}
          className="bg-red-500 text-white px-3 py-1 rounded"
        >
          Sign Out
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => signIn('github')}
      className="bg-black text-white px-3 py-1 rounded"
    >
      Sign in with GitHub
    </button>
  );
}