import { AuthButtons } from './components/AuthButtons';
'use client';
import { useState } from 'react';

export default function HomePage() {
  const [category, setCategory] = useState('Writing');
  const [input, setInput] = useState('');
  const [results, setResults] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category, input }),
    });
    const data = await res.json();
    setResults(data.prompts);
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <AuthButtons />
      <h1 className="text-3xl font-bold">🎯 PromptGenie</h1>
      <div>
        <label className="block mb-1">Select Category</label>
        <select
          className="w-full border rounded px-3 py-2"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option>Writing</option>
          <option>Code</option>
          <option>Design</option>
          <option>Marketing</option>
        </select>
      </div>
      <div>
        <label className="block mb-1">What do you want to do?</label>
        <textarea
          className="w-full border rounded px-3 py-2"
          rows={4}
          value={input}
          onChange={(e) => setInput(e.target.value)}
        ></textarea>
      </div>
      <button
        onClick={handleGenerate}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        {loading ? 'Generating...' : 'Generate Prompt'}
      </button>

      {results.length > 0 && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold">Generated Prompts:</h2>
          <ul className="mt-2 space-y-2">
            {results.map((prompt, idx) => (
              <li key={idx} className="bg-white p-4 rounded shadow">
                {prompt}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}