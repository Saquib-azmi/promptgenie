'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const [prompts, setPrompts] = useState<any[]>([]);

  useEffect(() => {
    const fetchPrompts = async () => {
      if (!session?.user?.email) return;
      const res = await fetch('/api/prompts');
      const data = await res.json();
      setPrompts(data.prompts);
    };
    fetchPrompts();
  }, [session]);

  if (status === 'loading') return <p>Loading...</p>;

  if (!session) return <p>Please sign in to view your prompts.</p>;

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">📜 Your Saved Prompts</h1>
      {prompts.length === 0 ? (
        <p>No prompts found.</p>
      ) : (
        <ul className="space-y-2">
          {prompts.map((p, idx) => (
            <li key={idx} className="bg-white p-4 rounded shadow">
              {p.text}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}