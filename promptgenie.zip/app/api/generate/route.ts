import { NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function POST(req: Request) {
  const { input, category } = await req.json();

  const systemPrompt = `You are a prompt engineer. Create 3 optimized prompts for a ${category} task. Be clear, concise, and structured.`;
  const userPrompt = `Task: ${input}`;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    temperature: 0.7,
  });

  const text = completion.choices[0].message.content || '';
  const prompts = text.split(/\n\d+\. /).filter(p => p.trim()).map(p => p.replace(/^\d+\. /, '').trim());

  return NextResponse.json({ prompts });
}