import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/options';
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.email) {
    return NextResponse.json({ prompts: [] });
  }

  const { data } = await supabase
    .from('prompts')
    .select('*')
    .eq('user_email', session.user.email)
    .order('created_at', { ascending: false });

  return NextResponse.json({ prompts: data || [] });
}